
/* JavaScript content from codiqa.ext.js in folder common */
// Put your custom code here
